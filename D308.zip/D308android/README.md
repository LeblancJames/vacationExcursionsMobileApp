Title: Vacation App
Purpose: An application help organize vacations and excursions for each vacation.
Directions: The main screen allows you to enter the vacation list screen through the main button. The vacation list screen has multiple features including adding, updating and deleting vacations from the list.
This screen also allows you to find more details about each vacation by clicking on the specific vacation name on the list of vacations. This screen allows you to update specific information about the vacation
itself by clicing on the specific edittext fields. The date entries will open a calender that allows you to modify the dates. This detailed vacation page also has a list of excursions that are related to the vacation.
The user can click on any specific excursion to go to the excursion details page which has information about the specific excursion. This page will allow you to add, update, or delete excursions.
Android Version:  
 android:minSdkVersion="24"
android:targetSdkVersion="35"
https://gitlab.com/wgu-gitlab-environment/student-repos/jshi32/d308-mobile-application-development-android/-/tree/working_branch?ref_type=heads
